import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  longText = `Get a input of the csv file as a input from the use and then get a future prediction value.`;
  longText1 = `Using the that csv file connected to the flask and do the linear regression and show the final graph of that future prediction.`;
  longText2 = `Using that csv file we have to do the future prediction of the particular year.`;
  filename: any;
  format: any;
  formfile: any;
  file: any;
  showLoader: boolean = false;
  ExcelData: any;
  fin: any;
  loginForm!: FormGroup;
  constructor(
    private _snackBar: MatSnackBar,
    private http: HttpClient,
    private formBulider: FormBuilder
  ) {}
  countries = [
    { id: 1, name: 'Yearly' },
    { id: 2, name: 'Monthly' },
    { id: 3, name: 'Weekly' },
    { id: 4, name: 'Daily' },
  ];
  answer1: any;
  ngOnInit(): void {
    this.loginForm = this.formBulider.group({
      file: [''],
      Perodic: [''],
      Num: [''],
    });
  }

  selectedMenu: any = 'Home';
  goTo(paramText: string) {
    this.selectedMenu = paramText;
  }
  onFileSelect(event: any) {
    try {
      this.file = event.target.files[0];
      if (this.file) {
        this.filename = this.file.name;
        this.format = this.file.name.split('.');
        this.format = this.format[1];
        console.log(this.format)
        if (this.format !='csv') {
          this._snackBar.open('Please select only CSV file', 'Close', {
            duration: 3000,
          });
          this.deleteFile();
        } else {
          this.formfile = new FormData();
          this.formfile.append('file', this.file);

          console.log('file uploaded', this.formfile);
        }
      }
    } catch (error) {
      this.deleteFile();
      console.log('no file was selected...');
    }
  }

  fileUpload(): void {
    console.log(this.formfile);

    if (this.file) {
      this.showLoader = true;
      let url = 'http://localhost:5000/file_upload';
      this.http.post(url, this.formfile).subscribe(
        (res) => {
          this.showLoader = false;
          this._snackBar.open('File successfully uploaded', 'Ok', {
            duration: 5000,
          });
          this.http.get('http://localhost:5000/final').subscribe((res) => {
            this.answer1 = res;
            console.log(this.answer1.data);
            this.fin = 'The prediction value is : ' + this.answer1.data;
          });
        },
        (error) => {
          this.showLoader = false;
          this._snackBar.open(error.message, 'Close', { duration: 5000 });
        }
      );
    } else {
      this._snackBar.open('Please select the file', 'Ok', { duration: 3000 });
    }
  }
  deleteFile() {
    this.file = null;
    this.format = null;
    this.filename = null;
    this.formfile.delete('file');
    // this.fileSelect
  }
  final() {
    this.http
      .post('http://localhost:5000/signup', this.loginForm.value)
      .subscribe((res) => {
        this._snackBar.open('uploaded', 'ok', { duration: 3000 });
      });
  }
}
