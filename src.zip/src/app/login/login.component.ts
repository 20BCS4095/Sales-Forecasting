import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup,FormControl, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {
loginForm!:FormGroup
constructor(private FormGroup:FormBuilder,private _http:HttpClient,private router:Router){
}
ngOnInit(): void{
  this.loginForm=this.FormGroup.group({
    'email':['',Validators.required],
    'password':['',Validators.required]
  })
}
login(){
  this._http.get<any>("http://localhost:3000/signup").subscribe(res=>{
const user=res.find((a:any)=>{
  return a.email===this.loginForm.value.email
})
const user1=res.find((a:any)=>{
  return a.password===this.loginForm.value.password
})
//a.password===this.loginForm.value.password
if(user && user1){
  alert("Login Successfull"); 
  this.loginForm.reset();
  this.router.navigate(['home'])
}
else if(user){
  alert("password incorrect")
}
else{
  alert("user not found You have to register") 
}
  },err=>{
    alert("server error")
  })
}
}
