import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SignupComponent } from './signup/signup.component';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { NgIf } from '@angular/common';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import {MatStepperModule} from '@angular/material/stepper';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule } from '@angular/material/icon';
import { FileUploadComponent } from './file-upload/file-upload.component';

const material=[
  MatCardModule,
  MatStepperModule,
  MatFormFieldModule,
 MatInputModule,
 MatTooltipModule
]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    HomeComponent,
    ForgetPasswordComponent,
    FileUploadComponent,

   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    NgIf,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
 BrowserAnimationsModule,
 MatProgressSpinnerModule,
 MatStepperModule,
 MatCardModule,
 MatSnackBarModule,
 MatIconModule,MatTooltipModule,
 MatFormFieldModule,

  ],
  providers: [],
  bootstrap: [AppComponent],
  exports:[FormsModule,
  ReactiveFormsModule,
...material]
})
export class AppModule { }
