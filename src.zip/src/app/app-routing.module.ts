
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { HomeComponent } from './home/home.component';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { LoginComponent } from 'src/app/login/login.component';
import { SignupComponent } from './signup/signup.component';
const routes: Routes = [
  {path:'login',component: LoginComponent},
  {path:'signup',component:SignupComponent},
  {
path:'home',component:HomeComponent
  },{path:'forget-password',component:ForgetPasswordComponent},{
path:'file-upload',component:FileUploadComponent
  },
  {
    path:'',redirectTo:'/login',pathMatch:'full'
    }


];

@NgModule({
  imports: [RouterModule.forRoot(routes,{enableTracing:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
