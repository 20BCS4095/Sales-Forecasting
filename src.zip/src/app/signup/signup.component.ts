import { Component, Injectable, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,FormControl, Validators } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  
})
@Injectable({
  providedIn:'root'
})
export class SignupComponent implements OnInit {
Form!: FormGroup;  
private basepath="http://localhost:3000/signup";
constructor(private formBulider: FormBuilder,private _http:HttpClient,private router:Router){

}
ngOnInit(): void {
  this.Form=this.formBulider.group({
'name':[null,[Validators.required]],
'email':[null,[Validators.required,Validators.email]],
'password':[null,[Validators.required,Validators.minLength(8)]],
'repassword':[null,[Validators.required,Validators.minLength(8)]]
  })
}
SignUp(){
  this._http.get<any>("http://localhost:3000/signup").subscribe(res=>{
    const user=res.find((a:any)=>{
      return a.email===this.Form.value.email 
    })
  if(user){
    alert("user already existed")
  }
  else{
    if(this.Form.value.name==null){
      alert("enter name")
    } 
    else if(this.Form.value.email==null){
  alert("enter valid email")
    }
    else if(this.Form.value.password==null){
      alert("enter password password should not null")
    }
    else if(this.Form.value.password!=this.Form.value.repassword ){
  alert("password mismatch")
    }
  else{
    this._http.post<any>(this.basepath,this.Form.value).subscribe(
      res=>{
      
    alert("Registration successfull");
    this.Form.reset();
    this.router.navigate(['login']) 
  },err=>{
    alert("cannot register")
  })
  }
  }
  })

}

}
