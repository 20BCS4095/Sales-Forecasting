import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {Chart,registerables} from 'chart.js';
import * as Highcharts from 'highcharts';
@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {
  chart:any;
  answer1:any;
  public n: number[]=[];
  public n1: number[]=[];
  ya:any;
 constructor(private http: HttpClient){ }
 
ngOnInit(): void {
  this.chart=document.getElementById("my_first_chart");
  Chart.register(...registerables);
  this.loadChart();
 
}
loadChart():void{
 
        
this.http.get("http://localhost:5000/display").subscribe((res)=>{
  this.answer1=res 
 this.n.push(this.answer1.y)
this.n.push(this.answer1.y1)
this.n.push(this.answer1.y2)
this.n.push(this.answer1.y3)
this.n.push(this.answer1.y4)
 this.n1.push(this.answer1.y)
 this.n1.push(this.answer1.y1)
 this.n1.push(this.answer1.y2)
 this.n1.push(this.answer1.y3)
 this.n1.push(this.answer1.y4)
   this.http.get("http://localhost:5000/final").subscribe((res)=>{
    this.answer1=res
    this.n1.push(this.answer1.data)
    
    if(this.answer1.s==1) {
      this.ya="after "+(2023+this.answer1.n)+" years";
      console.log(this.ya)
    }
    else if(this.answer1.s==2){
      this.ya="after "+this.answer1.n+" months"
    }
    else if(this.answer1.s==3){
this.ya=" after "+this.answer1.n+" weeks"
    }
    else{
      this.ya="after "+this.answer1.n+" days"
    }
new Chart(this.chart,{
 
  type:'line',
  data:{
    datasets:[
      {
data:this.n,
label:"Previous Data",
backgroundColor:'#007bff',
tension:0.2,
borderColor:"grey"
      },
      {
        data:this.n1,
        label:"Future prediction",
        backgroundColor:'red',
        tension:0.2,
        borderColor:"black"
      }
    ],
    labels:["year 2019","year 2020","year 2021","year 2022","year 2023",this.ya]
  },
  options:{
    responsive:true,
scales:{
  y:{
    beginAtZero:false,
  }
}
  }
});
})
})
}
}
