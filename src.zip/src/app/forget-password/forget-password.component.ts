import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent {
  forgetForm!:FormGroup
  postId: any;
  constructor(private FormGroup:FormBuilder,private _http:HttpClient,private router:Router){
  }
  ngOnInit(): void{
    this.forgetForm=this.FormGroup.group({
      'email':['',Validators.required],
      'password':['',Validators.required],
      'repassword':['',Validators.required]
    })
  }
  forgetlogin(){
    this._http.get<any>("http://localhost:3000/signup").subscribe(res=>{
      const user=res.find((a:any)=>{
        return a.email===this.forgetForm.value.email
      })
      if(user){
        this._http.put("http://localhost:3000/signup",this.forgetForm.value.password).subscribe(res=>{
          this.forgetForm.reset();
          this.router.navigate(['home'])
        })
        
      }
      else{
        alert("User not found")
      }
        },err=>{
          alert("server error")
        })
  }
}
